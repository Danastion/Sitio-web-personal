<template>

<!-- Nav Links -->
  <div id="app">
    <nav-list v-if="showNav" @close="showNav = false">
     <li> <router-link to="/">Home</router-link> |</li>
     <li>  <router-link to="/educacion">Educacion</router-link> | </li>
     <li>  <router-link to="/habilidades">Habilidades</router-link> |</li>
     <li>  <router-link to="/experiencia">Experiencia</router-link> |</li>
     <li>  <router-link to="/conversemos">Conversemos</router-link> |</li>
     <li>  <router-link to="/experiencia_b">EXPERIENCIA B</router-link> |</li>
    </nav-list>
    
    <div class="box">
      <button class="hamburger-menu" @click="showNav = true">&#9776;</button>
    </div>
  </div>

</template>

<script>
export default {

  data() {
    return {
      showNav: false
      
    }
  },
}

</script>

<style scoped>
.menu {
  margin: auto;
  display: flex;
  height: 100vh;
  background: rgba(197, 6, 27, 0.3);
}

.menu-content {
  list-style: none;
  text-align: center;
  margin: auto;
  width: 60%;
  padding: 10px 20px;
  line-height: 1.6;
}

li {
  font-size: 40px;
  font-weight: 300;
  padding: 12px 0 0 0;
  text-shadow: 2px 2px 2px gray;
}

li:not(:last-child) {
  border-bottom: 1px solid rgba(197, 6, 27, 0.3);
}

a {
  text-decoration: none;
  color: white;
}

a:hover {
  background: teal;
  padding: 0 40px;
  border-radius: 5px;
}

.nav-close {
  color: rgba(197, 6, 27, 0.6);
  background-color: transparent;
  border: none;
  margin: 20px 30px;
  font-size: 30px;
  font-weight: 300;
  position: absolute;
  top: 0;
  right: 0;
}

.nav-close:hover {
  background-color: white;
  border-radius: 25px;
}

.box {
  padding: 20px;
}

.hamburger-menu {
  float: right;
  padding: 10px 15px;
  font-size: 20px;
  border-radius: 5px;
  background-color: white;
  color: rgba(197, 6, 27, 0.6);
}

h2 {
  color: teal;
}
  
</style>
