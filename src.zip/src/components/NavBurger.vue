<template>
<div class="menu">
 <!-- Hamburger Menu -->  
    <div class="menu">
      <div class="menu-background"></div>
      <ul class="menu-content">
          <slot><nav-list/></slot>
      </ul>
      <button class="nav-close" @click="$emit('close')">X</button>

</div>
</div>
</template> 

<script>
import navList from "@/components/navList.vue";
export default {
 components: {
    'nav-list': navList
  },
  data() {
    return {
      showNav: false
      
    }
  },
}

</script>

<style scoped>
.menu {
  margin: auto;
  display: flex;
/*   height: 100vh; */
  top: 0;
  right: 0;
  background: rgba(197, 6, 27, 0.3);
}

.menu-content {
  list-style: none;
  text-align: center;
  margin: auto;
  width: 100%;
  padding: 10px 20px;
  line-height: 1.6;
}



a {
  text-decoration: none;
  color: white;
}

a:hover {
  background: teal;
  padding: 0 40px;
  border-radius: 5px;
}

.nav-close {
  color: rgba(197, 6, 27, 0.6);
  background-color: transparent;
  border: none;
  margin: 20px 30px;
  font-size: 30px;
  font-weight: 300;
  position: absolute;
  top: 0;
  right: 0;
}

.nav-close:hover {
  background-color: white;
  border-radius: 25px;
}

.box {
  padding: 20px;
}

.hamburger-menu {
  float: right;
  padding: 10px 15px;
  font-size: 20px;
  border-radius: 5px;
  background-color: white;
  color: rgba(197, 6, 27, 0.6);
}

h2 {
  color: teal;
}
  
</style>
