<template>
  <div class="color-fondo">
    <Titulo texto="Nelson Espinoza" />
    <h4>Diseñador y Frontend</h4>
  </div>
</template>

<script>
import Titulo from "../components/Titulo";
export default {
  components: {
    Titulo
  }
};
</script>

<style scoped>
.color-fondo {
  background-color: #ff4400;
  height: 100vh;
  margin: 0;
  border: 0;
}
</style>
