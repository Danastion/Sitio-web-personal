<template>
  <div>
<NavBurger/>
    <HomeComp/>
  </div>
</template>

<script>
import HomeComp from "../components/HomeComp";
import NavBurger from "../components/NavBurger";
export default {
  components: {
    HomeComp, NavBurger
  }
};
</script>

<style scoped>
</style>
