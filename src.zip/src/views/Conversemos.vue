<template>
<div>
     <NavBurger/>
    <Titulo texto="Conversemos"/>
    <span>Télefono</span>
    <h4>+569 36944264</h4>

    <span>Email</span>
    <h4><a href="mailto:nelespinoza@outlook.com"> nelespinoza@outlook.com</a></h4>

    <span>Sígueme</span>
 <li><a href="https://twitter.com/Goldi69s" target="_blank"><i class="fab fa-twitter"></i></a></li>
 <li><a href="https://twitter.com/Goldi69s" target="_blank"><i class="fab fa-dribble"></i></a></li>

   
</div>

</template>

<script>
import Titulo from '../components/Titulo'
import NavBurger from "../components/NavBurger";
export default {
    components:{
        Titulo, NavBurger
    }
}
</script>

<style scoped>
body {
    background-color: #FF4400;
  }
</style>